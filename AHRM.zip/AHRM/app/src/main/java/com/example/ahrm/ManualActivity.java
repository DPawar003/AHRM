package com.example.ahrm;
import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class ManualActivity extends AppCompatActivity {

    @SuppressLint("UseSwitchCompatOrMaterialCode")
    private Switch switchFan, switchValve, switchPump;
    private DatabaseReference databaseRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.manual_activity);

        // Initialize the switches
        switchFan = findViewById(R.id.switch_fan);
        switchValve = findViewById(R.id.switch_valve);
        switchPump = findViewById(R.id.switch_pump);

        // Initialize Firebase Database reference
        databaseRef = FirebaseDatabase.getInstance().getReference("devices");

        // Fan switch
        switchFan.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                setupSwitchListener(switchFan, "fan");
                if (isChecked) {
                    // Fan is ON
                    Toast.makeText(ManualActivity.this, "Fan is ON", Toast.LENGTH_SHORT).show();
                } else {
                    // Fan is OFF
                    Toast.makeText(ManualActivity.this, "Fan is OFF", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Solenoid Valve switch
        switchValve.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                setupSwitchListener(switchValve, "solenoid_valve");
                if (isChecked) {
                    // Solenoid Valve is ON
                    Toast.makeText(ManualActivity.this, "Solenoid Valve is ON", Toast.LENGTH_SHORT).show();
                } else {
                    // Solenoid Valve is OFF
                    Toast.makeText(ManualActivity.this, "Solenoid Valve is OFF", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Submersible Pump switch
        switchPump.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                setupSwitchListener(switchPump, "submersible_pump");
                if (isChecked) {
                    // Submersible Pump is ON
                    Toast.makeText(ManualActivity.this, "Submersible Pump is ON", Toast.LENGTH_SHORT).show();
                } else {
                    // Submersible Pump is OFF
                    Toast.makeText(ManualActivity.this, "Submersible Pump is OFF", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void setupSwitchListener(Switch switchComponent, final String componentName) {
        switchComponent.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                // Send data to Firebase
                databaseRef.child(componentName).setValue(isChecked);

                // Show a Toast message
                String state = isChecked ? "ON" : "OFF";
                Toast.makeText(ManualActivity.this, componentName + " is " + state, Toast.LENGTH_SHORT).show();
            }
        });
    }

}