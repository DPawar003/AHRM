package com.example.ahrm;

import android.content.Intent;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import android.widget.Button;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {

    private TextView waterQualityValue, waterTemperatureValue, humidityValue, pHValue, waterLevelValue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        // Initialize TextViews
        humidityValue = findViewById(R.id.humidityValue);                   // DHT_11 Temperature
        waterLevelValue = findViewById(R.id.waterLevelValue);               // Float Level
        waterQualityValue = findViewById(R.id.waterQualityValue);           // TDS Water Quality
        waterTemperatureValue = findViewById(R.id.waterTemperatureValue);   // Water Temperature
        pHValue = findViewById(R.id.pHValue);                               // pH Sensor Value


        // Get references to the sensor data paths
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference tdsRef = database.getReference("Sensors/TDS/Water_Quality");
        DatabaseReference waterTempRef = database.getReference("Sensors/Water/Temperature");
        DatabaseReference dhtTempRef = database.getReference("Sensors/DHT_11/Humidity");
        DatabaseReference phRef = database.getReference("Sensors/pH_Sensor/pH_Value");
        DatabaseReference floatRef = database.getReference("Sensors/Float/Level");



        // Attach listeners to read data
        tdsRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                Long waterQuality = dataSnapshot.getValue(Long.class);
                if (waterQuality != null) {
                    waterQualityValue.setText(String.valueOf(waterQuality));
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });


        waterTempRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {Long temperature = dataSnapshot.getValue(Long.class);
                if (temperature != null) {
                    waterTemperatureValue.setText(String.valueOf(temperature));
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                // Handle errors
            }
        });


        dhtTempRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                Long humidity = dataSnapshot.getValue(Long.class);
                if (humidity != null) {
                    humidityValue.setText(String.valueOf(humidity));
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                // Handle errors
            }
        });


        phRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                Long pH_Value = dataSnapshot.getValue(Long.class);
                if (pH_Value != null) {
                    pHValue.setText(String.valueOf(pH_Value));
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                // Handle errors
            }
        });


        floatRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                Boolean waterLevel = dataSnapshot.getValue(Boolean.class);
                if (waterLevel != null) {
                    if(waterLevel) {
                        waterLevelValue.setText(String.valueOf("High"));
                    } else {
                        waterLevelValue.setText(String.valueOf("Low"));
                    }

                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                // Handle errors
            }
        });



        // Initialize the button
        Button buttonManualControl = findViewById(R.id.buttonManual);

        // Set click listener for the button
        buttonManualControl.setOnClickListener(v -> {
            // Intent to navigate to ManualControlActivity
            Intent intent = new Intent(MainActivity.this, ManualActivity.class);
            startActivity(intent);
        });
    }

}

